<?php

namespace Doctrine\Tests\Common\Reflection;

class DeeperNamespaceParent extends Dummies\NoParent
{
}
